


public class Block0 implements Block{
	private boolean inGame; 
	
	public void moveRight() {
		// TODO Auto-generated method stub
		
	}


	public void moveUp() {
		// TODO Auto-generated method stub
		
	}


	public void moveDown() {
		// TODO Auto-generated method stub
		
	}

	public void rotate() {
		// TODO Auto-generated method stub
		
	}


	public boolean canRotate() {
		// TODO Auto-generated method stub
		return false;
	}


	public boolean movelimitRight() {
		// TODO Auto-generated method stub
		return false;
	}


	public boolean movelimitUp() {
		// TODO Auto-generated method stub
		return false;
	}


	public boolean movelimitDown() {
		// TODO Auto-generated method stub
		return false;
	}
	
	public void clearBlock(){}
	public boolean inGame() {
		return this.inGame;
	}

}
